package nl.han.oose.dea.exeptions;

public class LoginException extends RuntimeException{

}
