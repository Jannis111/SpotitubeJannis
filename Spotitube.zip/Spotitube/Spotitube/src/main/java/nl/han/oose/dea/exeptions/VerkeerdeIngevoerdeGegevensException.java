package nl.han.oose.dea.exeptions;

public class VerkeerdeIngevoerdeGegevensException extends RuntimeException{


}
