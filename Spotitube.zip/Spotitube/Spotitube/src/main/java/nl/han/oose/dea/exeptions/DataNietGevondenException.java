package nl.han.oose.dea.exeptions;

public class DataNietGevondenException extends RuntimeException {
}
