package nl.han.oose.dea.exeptions;

public class IdAlreadyInUseException extends RuntimeException{
}
